package com.example.demo.Customer.Model;

public enum KycStatus {
    PENDING,
    VERIFIED,
    REJECTED

    }
