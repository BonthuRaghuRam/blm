package com.example.Model1.controller;
import com.example.Model1.model.Customer;
import com.example.Model1.service.CustomerService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private CustomerService customerService;

    // Show profile
    @GetMapping
    public String profile(HttpSession session, Model model) {
        Customer sessionUser = (Customer) session.getAttribute("user");
        if (sessionUser == null) {
            return "redirect:/login";
        }

        Customer customer = customerService.getCustomerDetails(Long.valueOf(sessionUser.getCustomerid()));
        model.addAttribute("customer", customer);
        return "profile";
    }

    // Update profile
    @PostMapping("/update")
    public String updateProfile(@ModelAttribute("customer") Customer customer,
                                HttpSession session,
                                Model model) {
        try {
            Customer updated = customerService.updateCustomerProfile(Long.valueOf(customer.getCustomerid()), customer);
            session.setAttribute("user", updated);
            model.addAttribute("customer", updated);
            model.addAttribute("success", "Profile updated successfully!");
        } catch (Exception e) {
            model.addAttribute("error", "Update failed: " + e.getMessage());
        }
        return "profile";
    }
}
