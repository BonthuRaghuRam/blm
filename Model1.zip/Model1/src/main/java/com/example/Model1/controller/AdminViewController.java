package com.example.Model1.controller;
import com.example.Model1.model.Customer;
import com.example.Model1.service.CustomerService;
import com.example.Model1.service.LoanApplicationService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminViewController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private LoanApplicationService loanApplicationService;

    // Show admin dashboard
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Customer admin = (Customer) session.getAttribute("user");
        if (admin == null || admin.getUserRole() != Customer.UserRole.ADMIN) {
            return "redirect:/login";
        }

        List<Customer> customers = customerService.getAllCustomers();

        long verified = customers.stream().filter(c -> c.getKycStatus() == Customer.KycStatus.VERIFIED).count();
        long pending = customers.stream().filter(c -> c.getKycStatus() == Customer.KycStatus.PENDING).count();
        long rejected = customers.stream().filter(c -> c.getKycStatus() == Customer.KycStatus.REJECTED).count();

        model.addAttribute("totalCustomers", customers.size());
        model.addAttribute("verifiedKyc", verified);
        model.addAttribute("pendingKyc", pending);
        model.addAttribute("rejectedKyc", rejected);

        model.addAttribute("loanApplications", loanApplicationService.getAllLoanApplications());

        return "admin-dashboard";
    }

    // Approve loan
    @GetMapping("/loans/approve/{id}")
    public String approveLoan(@PathVariable Integer id) {
        loanApplicationService.approveLoan(id);
        return "redirect:/admin/dashboard";
    }

    // Reject loan
    @GetMapping("/loans/reject/{id}")
    public String rejectLoan(@PathVariable Integer id) {
        loanApplicationService.rejectLoan(id);
        return "redirect:/admin/dashboard";
    }
}
