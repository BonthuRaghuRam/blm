package com.example.Model1.controller;
import com.example.Model1.model.Customer;
import com.example.Model1.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RegisterController {

    @Autowired
    private CustomerService customerService;

    // Show registration page
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("customer", new Customer());
        return "register";
    }

    // Handle form submission
    @PostMapping("/register")
    public String register(@ModelAttribute("customer") Customer customer,
                           Model model) {
        try {
            customerService.registerCustomer(customer);
            model.addAttribute("success", "Registration successful! Please login.");
            return "login";  // after registration, redirect to login page
        } catch (Exception e) {
            model.addAttribute("error", "Registration failed: " + e.getMessage());
            return "register";
        }
    }
}


