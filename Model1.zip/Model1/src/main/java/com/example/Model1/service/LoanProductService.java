package com.example.Model1.service;
import com.example.Model1.model.LoanProduct;
import com.example.Model1.repository.LoanProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanProductService {

    @Autowired
    private LoanProductRepository loanProductRepository;

    public List<LoanProduct> getAllProducts() {
        return loanProductRepository.findAll();
    }
}
