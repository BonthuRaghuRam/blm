package com.example.Model1.service;
import com.example.Model1.model.LoanApplication;
import com.example.Model1.repository.LoanApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanApplicationService {

    @Autowired
    private LoanApplicationRepository loanApplicationRepository;

    public List<LoanApplication> getAllLoanApplications() {
        return loanApplicationRepository.findAll();
    }

    public void approveLoan(Integer id) {
        LoanApplication loan = loanApplicationRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new RuntimeException("Loan not found"));
        loan.setApprovalStatus(LoanApplication.ApprovalStatus.APPROVED);
        loanApplicationRepository.save(loan);
    }

    public void rejectLoan(Integer id) {
        LoanApplication loan = loanApplicationRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new RuntimeException("Loan not found"));
        loan.setApprovalStatus(LoanApplication.ApprovalStatus.REJECTED);
        loanApplicationRepository.save(loan);
    }
}
