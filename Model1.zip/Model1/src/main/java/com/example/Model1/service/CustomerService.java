package com.example.Model1.service;

import com.example.Model1.model.Customer;
import com.example.Model1.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // Register new customer
    public Customer registerCustomer(Customer customer) {
        // Default KYC = PENDING
        customer.setKycStatus(Customer.KycStatus.PENDING);
        return customerRepository.save(customer);
    }

    // Login check
    public Customer login(String email, String password) {
        return customerRepository.findByEmailAndPassword(email, password);
    }

    // Get details of a single customer
    public Customer getCustomerDetails(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
    }

    // Update profile
    public Customer updateCustomerProfile(Long id, Customer updatedCustomer) {
        Customer existing = getCustomerDetails(id);
        existing.setName(updatedCustomer.getName());
        existing.setEmail(updatedCustomer.getEmail());
        existing.setPhone(updatedCustomer.getPhone());
        existing.setAddress(updatedCustomer.getAddress());
        existing.setKycStatus(updatedCustomer.getKycStatus());
        return customerRepository.save(existing);
    }

    // Get all customers (Admin use)
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
}

